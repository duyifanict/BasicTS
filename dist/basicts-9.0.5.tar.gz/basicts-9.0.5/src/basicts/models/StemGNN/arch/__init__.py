from .stemgnn_arch import StemGNN
