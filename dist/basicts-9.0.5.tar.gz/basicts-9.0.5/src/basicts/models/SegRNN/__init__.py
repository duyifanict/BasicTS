from .arch import SegRNN
from .config.segrnn_config import SegRNNConfig
