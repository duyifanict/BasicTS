from .arch import LightTS
from .config.lightts_config import LightTSConfig
