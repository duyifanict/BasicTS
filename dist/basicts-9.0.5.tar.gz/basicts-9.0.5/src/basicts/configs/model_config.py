from easydict import EasyDict


class BasicTSModelConfig(EasyDict):
    pass
