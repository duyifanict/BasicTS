from .timekan_arch import TimeKAN
