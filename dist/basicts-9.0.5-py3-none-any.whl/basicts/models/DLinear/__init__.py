from .arch import DLinear
from .config.dlinear_config import DLinearConfig
