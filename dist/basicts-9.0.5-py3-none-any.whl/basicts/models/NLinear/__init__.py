from .arch import NLinear
from .config.nlinear_config import NLinearConfig
